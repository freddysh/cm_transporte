$(document).ready(function() {
	if ($(".template__table_sortable table").length) {
		$(".template__table_sortable table").tablesorter();
	}
});