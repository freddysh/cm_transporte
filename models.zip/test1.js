var net=require('net');
var sta=require('./estadisticas.js');
var Ruta = require('./models/modelo_ruta').ruta;
var i=0;
var j=0;
var y=0;
var Rutas;
  Ruta.getLatLon(72,function(err,ruta){
      if(typeof ruta !== 'undefined' && ruta.length > 0)
      {

         Rutas=[];
            for(var a in ruta)
            {
              //console.log(ruta[a].color);
              var datos={
                  lon:ruta[a].lon,
                  lat:ruta[a].lat
                }
                Rutas.push(datos);
     
            }
      }
      else console.log('error');
        
     });

  
function connect(){
  process.stdout.write('#');
  var time=Date.now();
  var conn=net.createConnection(60000);
  var latencyTime=Date.now();

  conn.on('connect',function(){
    sta.collect('connect',Date.now()-time);
   console.log('conected');
    conn.write('CARRO'+i);
  
  });
  j=i;
  
     
     sta.collect('data',Date.now()-latencyTime);
     setInterval(function(){
      conn.write(Rutas[y].lat+','+Rutas[y].lon+',0.83,CARRO1,121017,14290500,1');

      y++;
      
    },5000);
     
   
  conn.on('close',function(){
   console.log('closed');
   conn.end();
  });
  i++;
}

setInterval(function(){ if(i<1) connect()},5);

process.on('SIGINT',function(){
  console.log('\n######## sumary:')
  sta.sumarize();
  process.exit();

});

